Para arrancar el proyecto debe ejecutar en el terminal la siguiente instrucción desde la propia carpeta del proyecto:

> npm install